package datalayer.dao;

import businesslogic.entities.Aircraft;

public interface AircraftDAO extends BaseDAO<Aircraft, Integer> {
    // No extra methods needed right now
}
