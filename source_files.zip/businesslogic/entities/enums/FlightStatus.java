package businesslogic.entities.enums;
public enum FlightStatus {
    SCHEDULED,
    DELAYED,
    CANCELLED,
    DEPARTED,
    ARRIVED
}
