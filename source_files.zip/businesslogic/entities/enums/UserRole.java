package businesslogic.entities.enums;
public enum UserRole {
    CUSTOMER,
    FLIGHT_AGENT,
    SYSTEM_ADMIN
}
