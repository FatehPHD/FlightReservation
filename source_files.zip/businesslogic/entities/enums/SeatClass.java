package businesslogic.entities.enums;
public enum SeatClass {
    ECONOMY,
    BUSINESS,
    FIRST
}
