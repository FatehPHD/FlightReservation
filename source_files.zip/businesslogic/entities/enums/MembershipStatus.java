package businesslogic.entities.enums;

public enum MembershipStatus {
    REGULAR,
    SILVER,
    GOLD,
    PLATINUM
}
